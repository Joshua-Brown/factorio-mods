require("config")
require("core")
require("prototypes.category")
require("prototypes.entities")
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")
data.raw["assembling-machine"]["oil-refinery"].fast_replaceable_group = "assembling-machine"