blank =
 {
      filename = "__Concrete_Lamppost__/graphics/concrete_lamp-sheet.png",
      priority = "extra-high",
      width = 1,
      height = 1
 }


data:extend({

{
    type = "item",
    name = "concrete-lamppost",
    icon = "__Concrete_Lamppost__/graphics/concrete_lamp_icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "a[energy]-d[concrete-lamp]",
    place_result = "concrete-lamppost",
    stack_size = 50
  },

  {
    type = "item",
    name = "concrete-lamp",
    icon = "__Concrete_Lamppost__/graphics/concrete_lamp_icon.png",
    flags = {"goes-to-quickbar"},
    subgroup = "energy-pipe-distribution",
    order = "a[energy]-d[concrete-lamp]",
    place_result = "concrete-lamp",
    stack_size = 50
  },

{
    type = "recipe",
    name = "concrete-lamp",
    enabled = false,
    ingredients =
    {
      {"wood", 2},
      {"copper-cable", 2}
    },
    result = "concrete-lamp",
    result_count = 1
  },

  {
    type = "recipe",
    name = "concrete-lamppost",
    enabled = false,
    ingredients =
    {
      {"concrete", 6},
      {"iron-stick", 8},
      {"small-lamp", 1},
      {"copper-cable", 4}
    },
    result = "concrete-lamppost",
    result_count = 1
  },

{
    type = "electric-pole",
    name = "concrete-lamppost",
    icon = "__Concrete_Lamppost__/graphics/concrete_lamp_icon.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "concrete-lamppost"},
    max_health = 80,
    corpse = "small-remnants",
    resistances = 
    {
      {
        type = "impact",
        percent = 90
      }
    },
    collision_box = {{-0.15, -0.15}, {0.15, 0.15}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    drawing_box = {{-0.5, -4.0}, {1.5, 0.5}},
    maximum_wire_distance = 15,
    supply_area_distance = 0.5,
    mined_sound = {filename = "__base__/sound/deconstruct-bricks.ogg" },
    vehicle_impact_sound =  {filename = "__base__/sound/car-stone-impact.ogg", volume = 1.0 },
    pictures =
    {
      filename = "__Concrete_Lamppost__/graphics/concrete_lamp-sheet.png",
      priority = "extra-high",
      width = 160,
      height = 160,
      direction_count = 4,
      shift = {0.95, -2.1}
    },
    connection_points =
    {
      {
        shadow =
        {
          copper = {2.7, 0.8},
          red = {2.3, 0.2},
          green = {2.5, 0.2}
        },
        wire =
        {
          copper = {0.3, -3.4},
          red = {-0.2,-2.8},
          green = {0.2,-2.6}
        }
      },
      {
        shadow =
        {
          copper = {2.7, 0.35},
          red = {2.2, -0.0},
          green = {2.4, 0.0}
        },
        wire =
        {
          copper = {0.28, -3.1},
          red = {0.1, -2.8},
          green = {-0.3, -2.6}
        }
      },
      {
        shadow =
        {
          copper = {2.4, 0.1},
          red = {2.3, -0.1},
          green = {2.2, 0.0}
        },
        wire =
        {
          copper = {-0.3, -3.0},
          red = {0.2, -2.6},
          green = {-0.2, -2.8}
        }
      },
      {
        shadow =
        {
          copper = {2.2, -0.1},
          red = {2.2, -0.0},
          green = {2.4, 0.0}
        },
        wire =
        {
          copper = {-0.3, -3.4},
          red = {-0.2, -2.6},
          green = {0.2, -2.8}
        }
      }
    },
    radius_visualisation_picture = blank
  },

  {
    type = "lamp",
    name = "concrete-lamp",
    icon = "__Concrete_Lamppost__/graphics/concrete_lamp_icon.png",
    flags = {"placeable-off-grid", "not-on-map"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "stone-brick"},
    selectable_in_game = false,
    max_health = 55,
    corpse = "small-remnants",
    collision_box = {{-0, -0}, {0, 0}},
    selection_box = {{-0.4, -0.4}, {0.4, 0.4}},
    vehicle_impact_sound =  {filename = "__base__/sound/car-stone-impact.ogg", volume = 1.0 },
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input"
    },
    energy_usage_per_tick = "5KW",
    light = {intensity = 0.75, size = 30},
    picture_off = blank,    
    picture_on = blank,
    circuit_wire_connection_point =
    {
      shadow =
      {
        red = {0.759375, -0.096875},
        green = {0.759375, -0.096875},
      },
      wire =
      {
        red = {0.30625, -0.39375},
        green = {0.30625, -0.39375},
      }
    },

    circuit_wire_max_distance = 0
  },

{
    type = "technology",
    name = "concrete-lamppost",
    icon = "__Concrete_Lamppost__/graphics/concrete_lamp-tech.png",
    icon_size = 128,
    prerequisites = {"optics", "electric-energy-distribution-1", "concrete"},
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "concrete-lamppost"
      }
    },
    unit =
    {
      count = 100,
      ingredients = {{"science-pack-1", 1},{"science-pack-2", 1}},
      time = 30
    },
    order = "a-h-b"
  },

  })