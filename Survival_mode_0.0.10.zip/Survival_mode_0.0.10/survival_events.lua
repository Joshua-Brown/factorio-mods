script.on_event(defines.events.on_player_created, function(event)
	if game.get_player(event.player_index).controller_type ~= defines.controllers.character then
		return
	end
	local player = game.get_player(event.player_index)
	if not is_fake_player(player) then
		table.insert(global.survival, {player, Config.MaxOxygen, Config.MaxWater, Config.MaxFood})
		ui_init(player)
		player_starting_inventory(player)
	else
	end
end)

function player_starting_inventory(player)
	if (Config.DebugMode == true) then
		game.forces.player.research_all_technologies()
		player.insert({name="assembling-machine-2", count=2})
		player.insert({name="offshore-pump", count=1})
		player.insert({name="pipe", count=30})
		player.insert({name="pot", count=1})
		player.insert({name="copper-plate", count=20})
		player.insert({name="solar-panel", count=5})
		player.insert({name="big-electric-pole", count=10})
		player.insert({name="raw-wood", count=10})
		player.insert({name="potato-plant", count=10})
		player.insert({name="potato-plant2", count=10})
		player.insert({name="potato-plant3", count=10})
		player.insert({name="car", count=1})
		player.insert({name="power-armor", count=1})
	end	
	player.insert({name="empty-bottle", count=10})
	player.insert({name="water-bottle", count=30})
	player.insert({name="oxygen-bottle", count=30})
	player.insert({name="potato", count=100})
	player.insert({name="purifier", count=2})
	
	--armors handle
	local armor = player.get_inventory(defines.inventory.player_armor)
	local suit = {name="space-suit", count=1, health=0.8}
		
	if not armor.is_empty() and armor[1].name ~= "space-suit" then
		player.insert({name=armor[1].name,count=1,health=armor[1].health})
	end
	armor[1].set_stack(suit)
	
	armor = player.get_inventory(defines.inventory.player_armor)[1]
	if armor.valid_for_read and armor.has_grid then
		armor.grid.put({name = "oxygen-bottle", count=1})
	end		
end

--=============================================================================================
entityBuilt = function(event)
	if event.created_entity ~= nil and event.created_entity.valid then 
		if (event.created_entity.name == "potato-plant") then
			table.insert(global.potatoplant, {event.created_entity,0,Config.PlantsGrown1,Config.PlantsWither1})
			event.created_entity.minable = false
			event.created_entity.health = 1
		elseif (event.created_entity.name == "potato-plant2") then
			table.insert(global.potatoplant, {event.created_entity,0,Config.PlantsGrown2,Config.PlantsWither2})
			event.created_entity.minable = false
			event.created_entity.health = 1
		elseif (event.created_entity.name == "potato-plant3") then
			table.insert(global.potatoplant, {event.created_entity,0,Config.PlantsGrown3,Config.PlantsWither3})
			event.created_entity.minable = false
			event.created_entity.health = 1
		end
	end
end

entityRemoved = function(event)
	if event.entity ~= nil and event.entity.valid and 
		(event.entity.name == "potato-plant" or event.entity.name == "potato-plant2" or event.entity.name == "potato-plant3") then
		for i,v in ipairs(global.potatoplant) do
			if v[1] == event.entity then
				table.remove(global.potatoplant, i)
			end
		end
	end
end

hidden_button_control = function(event)
	if (event.element.name == "uihidden") then			-- 3 states (D=Disabled,F=Full,H=Half)
		if (event.element.caption == "D") then
			event.element.caption = "F"
		elseif (event.element.caption == "F") then
			event.element.caption = "H"
		elseif (event.element.caption == "H") then
			event.element.caption = "D"
		else
			event.element.caption = "F"
		end
		for _,v in ipairs(global.survival) do
			if v[1].controller_type == defines.controllers.character then
				update_gui_perform(v,true)
			end
		end
	end
end

script.on_event(defines.events.on_built_entity, entityBuilt)
script.on_event(defines.events.on_robot_built_entity, entityBuilt)

script.on_event(defines.events.on_preplayer_mined_item, entityRemoved)
script.on_event(defines.events.on_robot_pre_mined, entityRemoved)
script.on_event(defines.events.on_entity_died, entityRemoved)

script.on_event(defines.events.on_gui_click, hidden_button_control)