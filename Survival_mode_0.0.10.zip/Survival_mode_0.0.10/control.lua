require "config"
require "defines"
require "util"
require "survival_events"
require "survival_guis"
require "survival_remote"


--=============================================================================================
script.on_init(function(Initialize)
	if global.survival == nil then
		global.survival = {}
	end
	if global.potatoplant == nil then
		global.potatoplant = {}
	end	
end)

--=============================================================================================
script.on_event(defines.events.on_tick, function(event)
	handle_players()
	update_guis()
	handle_plants()
	if (#game.players > 1) then
		punishment_check()
	else
		dead_check()
	end
end)

--=============================================================================================
function is_fake_player(player)
	if player.name == "yarm-remote-viewer" or player.name == "fatcontroller" then
		return true
	else
		return false
	end
end

--=============================================================================================
function update_guis()
	if game.tick % (Config.TickCheck * 15) ~= 0 then return end			-- For each 1/4 TickCheck passed, the UI will be updated
	for _,v in ipairs(global.survival) do
		if v[1].controller_type == defines.controllers.character then
			update_gui_perform(v)
		end
	end
end

--=============================================================================================
function handle_players()
	if game.tick % (Config.TickCheck * 60) ~= 0 then return end
	for _,v in ipairs(global.survival) do
		local player = game.players[v[1].index]
		if (v[1].controller_type == defines.controllers.character) then
			if (oxygen_bottle_check(v[1])==true or player.driving) then
				v[2] = state_change(v[2],"add",Config.MaxOxygen,Config.OxygenIncreaseSpeed)
				if not player.driving and (math.random(1000) <= Config.OxygenBottleUseRatio) then
					oxygen_bottle_auto_use(v[1])
				end
			elseif (math.random(1000) <= Config.OxygenDecreaseRatio) then 
				v[2] = state_change(v[2],"reduce",Config.MaxOxygen,Config.OxygenDecreaseSpeed)
				player.print("Alert: Oxygen level decreasing")
			end
			if (math.random(1000) <= Config.WaterDecreaseRatio) then 
				v[3] = state_change(v[3],"reduce",Config.MaxWater,Config.WaterDecreaseSpeed)
			end
			if (math.random(1000) <= Config.FoodDecreaseRatio) then
				v[4] = state_change(v[4],"reduce",Config.MaxFood,Config.FoodDecreaseSpeed)
			end
			
			if v[3] <= 50 and water_bottle_auto_use(v[1]) then
				v[3] = v[3] + Config.WaterEffective
			end
			if v[4] <= 50 and potato_auto_use(v[1]) then
				v[4] = v[4] + Config.FoodEffective
			end
		end
	end
end

function dead_check()
	for _,v in ipairs(global.survival) do
		if v[1].controller_type == defines.controllers.character then	
			if (v[2] <= 0 or v[3] <=0 or v[4] <= 0) and (Config.DebugMode ~= true) then
				game.set_game_state{game_finished=true}
			end
		end
	end
end

function punishment_check()
	for _,v in ipairs(global.survival) do
		if v[1].controller_type == defines.controllers.character then	
			if (v[2] <= 0 or v[3] <=0 or v[4] <= 0) and (Config.DebugMode ~= true) then
				v[1].clear_items_inside()
				player_starting_inventory(v[1])
			end
		end
	end
end

function state_change(state_level,change_type,state_max,change_speed)
	if (change_type == "add") then
		state_level = state_level + change_speed
		if (state_level > state_max) then state_level = state_max end
	elseif (change_type == "reduce") then
		state_level = state_level - change_speed
		if (state_level <= 0) then state_level = -1 end
	end
	return state_level
end

function oxygen_bottle_check(player)
	local armor = player.get_inventory(defines.inventory.player_armor)[1]
	local items = player.get_inventory(defines.inventory.player_main)
	local check_result = false
	if armor.valid_for_read and armor.has_grid then
		for _,equip in pairs(armor.grid.equipment) do
			if (equip.name == "oxygen-bottle") and (items.get_item_count("oxygen-bottle") >= 1) then
				check_result = true 
			end
		end
	end
	return check_result
end

function oxygen_bottle_auto_use(player)
	local items = player.get_inventory(defines.inventory.player_main)
	items.remove{name="oxygen-bottle", count=1}
	items.insert{name="empty-bottle", count=1}
end

function water_bottle_auto_use(player)
	local check_result = false
	local items = player.get_inventory(defines.inventory.player_main)
	if items.get_item_count("water-bottle") >= 1 then
		items.remove{name="water-bottle", count=1}
		items.insert{name="empty-bottle", count=1}
		check_result = true
	end
	return check_result
end

function potato_auto_use(player)
	local check_result = false
	local items = player.get_inventory(defines.inventory.player_main)
	if items.get_item_count("raw-fish") >= 1 then
		items.remove{name="raw-fish", count=1}
		check_result = true
	elseif items.get_item_count("potato") >= 1 then
		items.remove{name="potato", count=1}
		check_result = true
	end
	if check_result == true then
		if items.get_item_count("empty-bottle") >= 2 then
			items.remove{name="empty-bottle", count=2}
			items.insert{name="fertilizer", count=2}
		elseif items.get_item_count("empty-bottle") >= 1 then
			items.remove{name="empty-bottle", count=1}
			items.insert{name="fertilizer", count=1}
		end
	end
	return check_result
end

--=============================================================================================
function handle_plants()
	if (game.tick % (Config.TreesTickCheck * 60) ~= 0) and (#global.potatoplant) then return end
	for i,v in ipairs(global.potatoplant) do
		if v[1].minable == false then
			if v[1].health + 1 >= Config.TreesMaxHealth then
				v[1].minable = true
			else
				if v[2] <= 0 then
					v[1].health = v[1].health + 1
					v[2] = v[3]
				else
					v[2] = v[2] -1
				end
			end
		else
			if v[2] <= 0 then
				v[1].health = v[1].health - 1
				v[2] = v[4]
			else
				v[2] = v[2] -1
			end
			if v[1].health <= 0 then
				v[1].destroy()
				table.remove(global.potatoplant, i)
			end
		end	
	end
end