function ui_init(player)
	local refresh_needed = false
	if player.gui.left["extra-ui"] == nil then
		player.gui.left.add({type="frame", name="extra-ui", direction="horizontal", style="survival_frame", caption="Survival Mod:"})
		refresh_needed = true
	end
	if player.gui.left["uihidden"] == nil then
		player.gui.left.add({type="button",name="uihidden", style="survival_button", caption="F"})		--unhidden
		refresh_needed = true
	end
	if refresh_needed == true then
		destroy_ui(player.gui.left["extra-ui"])
		create_ui(player.gui.left["extra-ui"])
	end
end

function create_ui(frame)
	frame.add({type="flow",name="Labels",caption="",direction="vertical",style="survival_flow"})
	frame.add({type="flow",name="Values",caption="",direction="vertical",style="survival_flow"})
	frame.Labels.add({type="label", name="Glabel", caption="GameTime", style="survival_label"})
	frame.Labels.add({type="label", name="Elabel", caption="Evo %", style="survival_label"})
	frame.Labels.add({type="label", name="Tlabel", caption="Time", style="survival_label"})
	frame.Labels.add({type="label", name="Olabel", caption="Oxygen", style="survival_label"})
	frame.Labels.add({type="label", name="Wlabel", caption="Water", style="survival_label"})
	frame.Labels.add({type="label", name="Flabel", caption="Food", style="survival_label"})	
	frame.Values.add({type="label", name="Gvalue", style="survival_label", caption=tostring(game_time_convert())})
	frame.Values.add({type="label", name="Evalue", style="survival_label", caption=tostring(evo_factor())})
	frame.Values.add({type="label", name="Tvalue", style="survival_label", caption=tostring(time_convert())})
	frame.Values.add({type="label", name="Ovalue", style="survival_label", caption=tostring(Config.MaxOxygen)})	
	frame.Values.add({type="label", name="Wvalue", style="survival_label", caption=tostring(Config.MaxWater)})	
	frame.Values.add({type="label", name="Fvalue", style="survival_label", caption=tostring(Config.MaxFood)})
end

function destroy_ui(frame)
	if frame.Labels ~= nil then frame.Labels.destroy() end
	if frame.Values ~= nil then frame.Values.destroy() end
end

function update_gui_perform(player_with_info,is_state_change)
	local player,valueo,valuew,valuef = player_with_info[1], player_with_info[2], player_with_info[3], player_with_info[4]
	local is_state_change = false or is_state_change
	ui_init(player)
	
	if is_state_change then
		if player.gui.left["uihidden"].caption == "F" then
			destroy_ui(player.gui.left["extra-ui"])
			create_ui(player.gui.left["extra-ui"])
		elseif player.gui.left["uihidden"].caption == "H" then
			destroy_ui(player.gui.left["extra-ui"])
			create_ui(player.gui.left["extra-ui"]) 
			player.gui.left["extra-ui"]["Labels"]["Glabel"].destroy()
			player.gui.left["extra-ui"]["Labels"]["Tlabel"].destroy()
			player.gui.left["extra-ui"]["Labels"]["Elabel"].destroy()
			player.gui.left["extra-ui"]["Values"]["Gvalue"].destroy()
			player.gui.left["extra-ui"]["Values"]["Tvalue"].destroy()
			player.gui.left["extra-ui"]["Values"]["Evalue"].destroy()
		else
			destroy_ui(player.gui.left["extra-ui"])
		end
	end
	
	if player.gui.left["uihidden"].caption == "F" then
		player.gui.left["extra-ui"]["Values"]["Gvalue"].caption = tostring(game_time_convert())
		player.gui.left["extra-ui"]["Values"]["Tvalue"].caption = tostring(time_convert())
		player.gui.left["extra-ui"]["Values"]["Evalue"].caption = tostring(evo_factor())
	end	
	if player.gui.left["uihidden"].caption == "F" or player.gui.left["uihidden"].caption == "H" then

		
		local labe = player.gui.left["extra-ui"]["Labels"]["Olabel"]
		local ival = player.get_inventory(defines.inventory.player_main).get_item_count("oxygen-bottle")
		label_coloring(labe,ival,Config.OxygenInvWarning)
		local cap = player.gui.left["extra-ui"]["Values"]["Ovalue"]
		cap.caption = tostring(valueo)
		level_coloring(cap,valueo)
		
		labe = player.gui.left["extra-ui"]["Labels"]["Wlabel"]
		ival = player.get_inventory(defines.inventory.player_main).get_item_count("water-bottle")
		label_coloring(labe,ival,Config.WaterInvWarning)
		cap = player.gui.left["extra-ui"]["Values"]["Wvalue"]
		cap.caption = tostring(valuew)
		level_coloring(cap,valuew)
		
		labe = player.gui.left["extra-ui"]["Labels"]["Flabel"]
		ival = player.get_inventory(defines.inventory.player_main).get_item_count("potato") + player.get_inventory(defines.inventory.player_main).get_item_count("raw-fish")
		label_coloring(labe,ival,Config.FoodInvWarning)
		cap = player.gui.left["extra-ui"]["Values"]["Fvalue"]
		cap.caption = tostring(valuef)
		level_coloring(cap,valuef)		
	end
end

function label_coloring(labe,ival,warning_level)
	if (ival <= 0) then labe.style.font_color = {r=1} 
	elseif (ival < warning_level) then labe.style.font_color = {r=1,g=1} 
	else labe.style.font_color = {r=1,g=1,b=1} end
end

function level_coloring(cap,tval)
	if (tval < 20) then cap.style.font_color = {r=1} 
	elseif (tval < 50) then cap.style.font_color = {r=1,g=1} 
	else cap.style.font_color = {r=1,g=1,b=1} end
end

function game_time_convert()
	local temptime = game.tick / 60					-- Convert "tick" to second
	local tempsec = math.floor(temptime % 60)
	local tempmin = math.floor((temptime/60)%60)
	local temphour = math.floor(temptime/3600)
	return string.format("%d",temphour % 24) .. ":" .. string.format("%02d",tempmin % 60) .. ":" .. string.format("%02d",tempsec)
end

function time_convert()
	local temptime = (game.daytime) * 1440
	local tempmin = math.floor(temptime % 60)
	local temphour = math.floor((temptime - tempmin)/60) + 12
	return string.format("%02d",temphour % 24) .. ":" .. string.format("%02d",tempmin)
end

function evo_factor()
	return string.format("%.6f",game.evolution_factor * 100)
end