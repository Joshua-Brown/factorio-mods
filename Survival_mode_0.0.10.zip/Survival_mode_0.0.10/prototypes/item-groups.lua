data:extend({
	{
		type = "item-subgroup",
		name = "survival",
		group = "fluids",
		order = "j"
	},
	{
		type = "item-subgroup",
		name = "potato",
		group = "fluids",
		order = "k"
	},
	{
		type = "item-subgroup",
		name = "recycle",
		group = "fluids",
		order = "l"
	}
})