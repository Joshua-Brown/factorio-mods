data:extend({ 
  {
	type = "recipe",
	name = "space-suit",
	enabled = "false",
	ingredients =
	{
	  {"plastic-bar", 20},
	  {"electronic-circuit",5}
	},
	result = "space-suit"
  },
  {
	type = "recipe",
	name = "poxygen",
	category = "water-related",
	subgroup = "fluid-recipes",
	enabled = "true",
	energy_required = 3,
	ingredients =
    {
	  {type="fluid", name="water", amount=10},
	  {type="item", name="copper-plate",amount=2}
	},
	results = {{type="fluid", name="pure-oxygen", amount=5}}
  },
  {
	type = "recipe",
	name = "pwater",
	category = "water-related",	
	subgroup = "fluid-recipes",
	enabled = "true",
	energy_required = 3,
	ingredients =
	{
	  {type="fluid", name="water", amount=10},
	  {type="item", name="wood",amount=5}
	},
	results = {{type="fluid", name="pure-water", amount=5}}
  },
  {
	type = "recipe",
	name = "water-treatment",
	icon = "__Survival_mode__/graphics/waox-bottle.png",
	category = "water-related",
	subgroup = "fluid-recipes",
	enabled = "true",
	energy_required = 5,
	ingredients =
    {
	  {type="fluid", name="water", amount=10},
	  {type="item", name="copper-plate",amount=2},
	  {type="item", name="wood",amount=5}
	},
	results = {
		{type="fluid", name="pure-oxygen", amount=5},
		{type="fluid", name="pure-water", amount=5}
	}
  },
  --===============================================================================
  {
	type = "recipe",
	name = "empty-bottle",
	enabled = "false",
	subgroup = "survival",
	order = "a[empty-bottle]",
	ingredients =
	{
	  {"steel-plate", 1}
	},
	result = "empty-bottle"
  },
  {
	type = "recipe",
	name = "oxygen-bottle",
	category = "crafting-with-fluid",
	subgroup = "survival",
	order = "b[oxygen-bottle]",
	enabled = "false",
	ingredients =
	{
	  {type="fluid", name="pure-oxygen", amount=5},
	  {type="item", name="empty-bottle", amount=1}
	},
	result = "oxygen-bottle"
  },
  {
	type = "recipe",
	name = "water-bottle",
	category = "crafting-with-fluid",
	subgroup = "survival",
	order = "c[water-bottle]",
	enabled = "false",
	ingredients =
	{
	  {type="fluid", name="pure-water", amount=5},
	  {type="item", name="empty-bottle", amount=1}
	},
	result = "water-bottle"
  },
  --===============================================================================
  {
	type = "recipe",
	name = "purifier",
	enabled = "true",
	subgroup = "potato",
	order = "a[purifier]",
	ingredients =
	{
	  {"steel-plate", 1},
	  {"electronic-circuit",5}
	},
	result = "purifier"
  },
  {
	type = "recipe",
	name = "pot",
	enabled = "true",
	subgroup = "potato",
	order = "b[pot]",
	ingredients =
	{
	  {"wood", 5}
	},
	result = "pot"
  },
  {
	type = "recipe",
	name = "potato-plant",
	enabled = "true",
	subgroup = "potato",
	order = "c[potato-plant]",
	ingredients =
	{
	  {"pot", 1},
	  {"potato", 1}	  
	},
	result = "potato-plant"
  },
  {
	type = "recipe",
	name = "potato-tree",
	enabled = "true",
	subgroup = "potato",
	order = "e[potato-plant]",
	ingredients =
	{
	  {"water-bottle", 1},
	  {"fertilizer", 1},
	  {"potato-plant2", 1}
	},
	result = "potato-plant3"
  },
  {
	type = "recipe",
	name = "recycle-fertilizer",
	category = "crafting-with-fluid",
	enabled = "false",
	subgroup = "recycle",
	order = "c",
	ingredients =
	{
	  {type="item", name="fertilizer", amount=1},
	  {type="fluid", name="pure-water", amount=1}
	},
	result = "empty-bottle"
  },
    {
	type = "recipe",
	name = "recycle-water-bottle",
	category = "crafting-with-fluid",
	enabled = "false",
	subgroup = "recycle",
	order = "b",
	ingredients =
	{
	  {type="item", name="water-bottle", amount=1},
	  {type="fluid", name="pure-water", amount=1}
	},
	result = "empty-bottle"
  },
    {
	type = "recipe",
	name = "recycle-oxygen-bottle",
	category = "crafting-with-fluid",
	enabled = "false",
	subgroup = "recycle",
	order = "a",
	ingredients =
	{
	  {type="item", name="oxygen-bottle", amount=1},
	  {type="fluid", name="pure-water", amount=1}
	},
	result = "empty-bottle"
  }
})