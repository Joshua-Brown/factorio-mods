local styles = data.raw["gui-style"].default

styles["survival_label"] = 
{
   type="label_style",
   parent="label_style",
   top_padding = 0,
   bottom_padding = 0,
   maximal_height = 12
}

styles["survival_flow"] = 
{
	type = "flow_style",
	parent = "flow_style"
}

styles["survival_button"] = 
{
	type = "button_style",
	parent = "button_style",
	top_padding = 1,
	right_padding = 1,
	bottom_padding = 1,
	left_padding = 1,
}

styles["survival_frame"] = 
{
	type = "frame_style",
	parent = "frame_style",
	graphical_set =
	{
		type = "composition",
		filename = "__core__/graphics/gui.png",
		priority = "extra-high-no-scale",
		corner_size = {3, 3},
		position = {15, 20}
	},
	flow_style= 
	{
		horizontal_spacing = 0,
		vertical_spacing = 0
	}
}