data:extend({
	{
		type = "tree",
		name = "potato-plant",
		icon = "__Survival_mode__/graphics/plant.png",
		flags = {"placeable-player", "player-creation", "breaths-air", "not-repairable"},
		minable = {hardness = 0.2, mining_time = 1, result = "potato-plant2"},
		max_health = 30,
		corpse = "dead-plant",
		emissions_per_tick = -0.005,
		subgroup = "trees",
		order = "a[tree]-x[potato-plant]",
		healing_per_tick = 0,
		resistances =
		{
		  {
			type = "fire", 
			percent = -80
		  }
		},
		collision_box = {{-0.25, -0.25}, {0.25, 0.25}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		pictures = 
		{
			filename = "__Survival_mode__/graphics/plant1.png",
			priority = "extra-high",
			width = 32,
			height = 32,
			shift = {0, 0}
		}		
	},  
	{
		type = "tree",
		name = "potato-plant2",
		icon = "__Survival_mode__/graphics/plant.png",
		flags = {"placeable-player", "player-creation", "breaths-air", "not-repairable"},
		minable =
		{
			mining_particle = "wooden-particle",
			mining_time = 1,
			result = "raw-wood",
			count = 20
		},
		max_health = 30,
		corpse = "dead-plant",
		emissions_per_tick = -0.5,
		subgroup = "trees",
		order = "a[tree]-y[potato-plant2]",
		healing_per_tick = 0,
		resistances =
		{
		  {
			type = "fire", 
			percent = -80
		  }
		},
		collision_box = {{-0.25, -0.25}, {0.25, 0.25}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		pictures =
		{
			filename = "__Survival_mode__/graphics/plant2.png",
			priority = "extra-high",
			width = 32,
			height = 32,
			shift = {0, 0}
		}
	},
	{
		type = "tree",
		name = "potato-plant3",
		icon = "__Survival_mode__/graphics/plant.png",
		flags = {"placeable-player", "player-creation", "breaths-air", "not-repairable"},
		minable = {hardness = 0.2, mining_time = 2, result = "potato", count = 4},
		max_health = 30,
		corpse = "dead-plant",
		emissions_per_tick = -5,
		subgroup = "trees",
		order = "a[tree]-z[potato-plant3]",
		healing_per_tick = 0,
		resistances =
		{
		  {
			type = "fire", 
			percent = -80
		  }
		},
		collision_box = {{-0.25, -0.25}, {0.25, 0.25}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		pictures =
		{
			filename = "__Survival_mode__/graphics/plant3.png",
			priority = "extra-high",
			width = 32,
			height = 32,
			shift = {0, 0}
		}
	},
	{
		type = "corpse",
		name = "dead-plant",
		icon = "__base__/graphics/icons/dead-tree.png",
		flags = {"placeable-neutral", "not-on-map"},
		collision_box = {{-0.4, -0.4}, {0.4, 0.4}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		tile_width = 1,
		tile_height = 1,
		selectable_in_game = false,
		time_before_removed = 60 * 60 * 5, 				-- 5 minutes
		final_render_layer = "remnants",
		subgroup = "remnants",
		order="d[remnants]-b[tree]-z",
		animation = stump_variations
	},
	{
    type = "assembling-machine",
    name = "purifier",
    icon = "__Survival_mode__/graphics/purifier.png",
    flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = 1, result = "purifier"},
    max_health = 300,
    corpse = "big-remnants",
    dying_explosion = "medium-explosion",
    collision_box = {{-2.4, -2.4}, {2.4, 2.4}},
    selection_box = {{-2.5, -2.5}, {2.5, 2.5}},
    crafting_categories = {"water-related"},
    crafting_speed = 1,
    has_backer_name = true,
    energy_source =
    {
      type = "electric",
      usage_priority = "secondary-input",
      emissions = 0.03 / 3.5
    },
    energy_usage = "420kW",
    ingredient_count = 4,
    animation =
    {
      north =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625, 0.484375}
      },
      east =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        x = 337,
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625, 0.484375}
      },
      south =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        x = 674,
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625, 0.484375}
      },
      west =
      {
        filename = "__base__/graphics/entity/oil-refinery/oil-refinery.png",
        x = 1011,
        width = 337,
        height = 255,
        frame_count = 1,
        shift = {2.515625, 0.484375}
      }
    },
    working_visualisations =
    {
      {
        north_position = {1.03125, -1.55},
        east_position = {-1.65625, -1.3},
        south_position = {-1.875, -2.0},
        west_position = {1.8437, -1.2},
        animation =
        {
          filename = "__base__/graphics/entity/oil-refinery/oil-refinery-fire.png",
          frame_count = 29,
          width = 16,
          height = 35,
          scale = 1.5,
          shift = {0, -0.5625},
          run_mode="backward"
        },
        light = {intensity = 0.4, size = 6}
      }
    },
    vehicle_impact_sound =  { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
    working_sound =
    {
      sound = { filename = "__base__/sound/oil-refinery.ogg" },
      idle_sound = { filename = "__base__/sound/idle1.ogg", volume = 0.6 },
      apparent_volume = 2.5,
    },
    fluid_boxes =
    {
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {-1, 3} }}
      },
      {
        production_type = "input",
        pipe_covers = pipecoverspictures(),
        base_area = 10,
        base_level = -1,
        pipe_connections = {{ type="input", position = {1, 3} }}
      },
      {
        production_type = "output",
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {-1, -3} }}
      },
      {
        production_type = "output",
        pipe_covers = pipecoverspictures(),
        base_level = 1,
        pipe_connections = {{ position = {1, -3} }}
      }
    },
    pipe_covers = pipecoverspictures()
  }
})