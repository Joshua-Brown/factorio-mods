data:extend({
	{
		type = "technology",
		name = "water-filtering",
		icon = "__Survival_mode__/graphics/water-bottle.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "empty-bottle"
		  },
		  {
			type = "unlock-recipe",
			recipe = "water-bottle"
		  },
		  {
			type = "unlock-recipe",
			recipe = "purifier"
			}
		},
		prerequisites = {},
		unit =
		{
		  count = 40,
		  ingredients = {{"science-pack-1", 1}},
		  time = 20
		},
		order = "a-b-d"
	},
	{
		type = "technology",
		name = "water-ionization",
		icon = "__Survival_mode__/graphics/oxygen-bottle.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "empty-bottle"
		  },
		  {
			type = "unlock-recipe",
			recipe = "oxygen-bottle"
		  },
		  {
			type = "unlock-recipe",
			recipe = "purifier"
			}
		},
		prerequisites = {},
		unit =
		{
		  count = 10,
		  ingredients = {{"science-pack-1", 4}},
		  time = 20
		},
		order = "a-b-e"
	},
	{
		type = "technology",
		name = "water-filtering-ionization",
		icon = "__Survival_mode__/graphics/waox-bottle.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "water-treatment"
		  }
		},
		prerequisites = {"water-ionization","water-filtering"},
		unit =
		{
		  count = 20,
		  ingredients = {{"science-pack-1", 5},{"science-pack-2", 5}},
		  time = 30
		},
		order = "a-b-f"
	},
	{
		type = "technology",
		name = "recycle",
		icon = "__Survival_mode__/graphics/orecycle.png",
		effects =
		{
		  {
			type = "unlock-recipe",
			recipe = "recycle-oxygen-bottle"
		  },
		  {
			type = "unlock-recipe",
			recipe = "recycle-water-bottle"
		  },
		  {
			type = "unlock-recipe",
			recipe = "recycle-fertilizer"
		  }
		},
		prerequisites = {},
		unit =
		{
		  count = 50,
		  ingredients = {{"science-pack-1", 1},{"science-pack-2", 1}},
		  time = 20
		},
		order = "a-b-g"
	}
 })