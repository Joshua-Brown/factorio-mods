data:extend({
	{
		type = "fluid",
		name = "pure-oxygen",
		default_temperature = 25,
		heat_capacity = "1KJ",
		base_color = {r=0.7, g=0.7, b=0.7},
		flow_color = {r=0.5, g=0.5, b=0.5},
		max_temperature = 50,
		icon = "__Survival_mode__/graphics/oxygen.png",
		pressure_to_speed_ratio = 0.8,
		flow_to_energy_ratio = 0.59,
		order = "a[fluid]-g[pure-oxygen]"
	},
	{
		type = "fluid",
		name = "pure-water",
		default_temperature = 25,
		heat_capacity = "100KJ",
		base_color = {r=0, g=0.34, b=0.6},
		flow_color = {r=0.7, g=0.7, b=0.7},
		max_temperature = 100,
		icon = "__Survival_mode__/graphics/water.png",
		pressure_to_speed_ratio = 0.4,
		flow_to_energy_ratio = 0.59,
		order = "a[fluid]-h[pure-water]"
	},
	{
		type = "item",
		name = "empty-bottle",
		order = "sur-b-a",
		icon = "__Survival_mode__/graphics/empty-bottle.png",
		flags = {"goes-to-main-inventory"},
		stack_size = 50
	},
	{
		type = "item",
		name = "oxygen-bottle",
		order = "sur-b-b",
		icon = "__Survival_mode__/graphics/oxygen-bottle.png",
		flags = {"goes-to-main-inventory"},
		placed_as_equipment_result = "oxygen-bottle",
		stack_size = 50
	},
	{
		type = "movement-bonus-equipment",
		name = "oxygen-bottle",
		icon = "__Survival_mode__/graphics/oxygen-bottle.png",
		flags = {"goes-to-main-inventory"},
		sprite = 
		{
		  filename = "__Survival_mode__/graphics/oxygen-bottle.png",
		  width = 64,
		  height = 64,
		  priority = "medium",
		},
		shape =
		{
		  width = 1,
		  height = 2,
		  type = "full"
		},
		energy_source =
		{
		  type = "electric",
		  usage_priority = "secondary-input"
		},
		energy_consumption = "1kW",
		movement_bonus = 0.1
	},
	{
		type = "item",
		name = "water-bottle",
		order = "sur-b-c",
		icon = "__Survival_mode__/graphics/water-bottle.png",
		flags = {"goes-to-main-inventory"},
		stack_size = 50
	},
	{
		type = "item",
		name = "potato",
		order = "sur-p-z",
		icon = "__Survival_mode__/graphics/potato.png",
		flags = {"goes-to-main-inventory"},
		stack_size = 50
	},
	{
		type = "item",
		name = "fertilizer",
		order = "sur-b-d",
		icon = "__Survival_mode__/graphics/fertilizer.png",
		flags = {"goes-to-main-inventory"},
		stack_size = 50
	},
	{
		type = "item",
		name = "purifier",
		order = "sur-p-a",
		icon = "__Survival_mode__/graphics/purifier.png",
		flags = {"goes-to-quickbar"},
		place_result = "purifier",
		stack_size = 5
	},
	{
		type = "item",
		name = "pot",
		order = "sur-p-b",
		icon = "__Survival_mode__/graphics/pot.png",
		flags = {"goes-to-main-inventory"},
		stack_size = 50
	},
	{
		type = "item",
		name = "potato-plant",
		order = "sur-p-w",
		icon = "__Survival_mode__/graphics/plant1.png",
		flags = {"goes-to-quickbar"},
		place_result = "potato-plant",
		stack_size = 50
	},
	{
		type = "item",
		name = "potato-plant2",
		order = "sur-p-ww",
		icon = "__Survival_mode__/graphics/plant2.png",
		flags = {"goes-to-quickbar"},
		subgroup = "potato",
		order = "d[potato-plant2]",
		place_result = "potato-plant2",
		stack_size = 50
	},
	{
		type = "item",
		name = "potato-plant3",
		order = "sur-p-y",
		icon = "__Survival_mode__/graphics/plant3.png",
		flags = {"goes-to-quickbar"},
		place_result = "potato-plant3",
		stack_size = 50
	},
	{
		type = "armor",
		name = "space-suit",
		icon = "__base__/graphics/icons/basic-armor.png",
		flags = {"goes-to-main-inventory"},
		resistances =
		{
		  {
			type = "explosion",
			decrease = 15,
			percent = 30
		  }
		},
		durability = 1000,
		subgroup = "armor",
		order = "d[space-suit]",
		stack_size = 1,
		equipment_grid = {width = 1, height = 2}
	},
  })