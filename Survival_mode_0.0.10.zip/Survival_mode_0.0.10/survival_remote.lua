remote.add_interface("survival", {
	init = function()
		for _, player in ipairs(game.players) do
			local found = false
			if not is_fake_player(player) then
				for _, v in ipairs(global.survival) do
					if v[1] == player then
						found = true
					end
				end

				if found == false then
					table.insert(global.survival, {player, Config.MaxOxygen, Config.MaxWater, Config.MaxFood})
					ui_init(player)
					player_starting_inventory(player)

					game.players[player.index].print("Survival mod initiated correctly.")
				else
					game.players[player.index].print("Survival mod was initiated before.")
				end
			else
			end
		end
	end,
	set_oxygen = function(player_name, amount)  
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				if (amount > Config.MaxOxygen) then amount = Config.MaxOxygen end
				if (amount < 0) then amount = 0 end
				v[2] = amount						-- valuetype, 2=oxygen, 3=water, 4=food
				update_gui(v)
			end
		end
	end,
	get_oxygen = function(player_name)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				return v[2]
			end
		end
	end,
	add_oxygen = function(player_name, amount)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				v[2] = v[2] + amount
				update_gui(v)
			end
		end
	end,
	set_food = function(player_name, amount)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				if (amount > Config.MaxFood) then amount = Config.MaxFood end
				if (amount < 0) then amount = 0 end
				v[4] = amount
				update_gui(v)
			end
		end
	end,
	get_food = function(player_name)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				return v[4]
			end
		end
	end,
	add_food = function(player_name, amount)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				v[4] = v[4] + amount
				update_gui(v)
			end
		end
	end,
	set_water = function(player_name, amount)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				if (amount > Config.MaxWater) then amount = Config.MaxWater end
				if (amount < 0) then amount = 0 end
				v[3] = amount
				update_gui(v)
			end
		end
	end,
	get_water = function(player_name)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				return v[3]
			end
		end
	end,
	add_water = function(player_name, amount)
		for _,v in ipairs(global.survival) do
			if v[1] == game.get_player(player_name) then
				v[3] = v[3] + amount
				update_gui(v)
			end
		end
	end,
})