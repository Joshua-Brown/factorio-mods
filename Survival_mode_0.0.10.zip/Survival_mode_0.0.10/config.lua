Config = {}

--Basic configuration
Config.DebugMode = false
Config.MaxOxygen = 100
Config.MaxFood = 100
Config.MaxWater = 100

--Affect the overall speed of this mod (second)
Config.TickCheck = 1

--The percentage that how frequents of the values will be drop
Config.OxygenBottleUseRatio = 1			--1=0.1%
Config.OxygenDecreaseRatio = 1000		--1000=100%
Config.FoodDecreaseRatio = 30			--30=3%
Config.WaterDecreaseRatio = 30			--30=3%

--The value will be added/dropped in game
Config.OxygenIncreaseSpeed = 4
Config.OxygenDecreaseSpeed = 30
Config.FoodDecreaseSpeed = 1
Config.WaterDecreaseSpeed = 1

--The value will be added after eat/drink the potato/water-bottle
Config.WaterEffective = 40
Config.FoodEffective = 40

--The bottles/potato warning level (color yellow of the text)
Config.OxygenInvWarning = 20
Config.FoodInvWarning = 20
Config.WaterInvWarning = 20

--The time will be spend on each TreesTick
Config.TreesTickCheck = 1					--second
Config.TreesMaxHealth = 30					--For example, PlantsGrown = 20, TreesMaxHealth = 30 and TreesTickCheck = 10, total grow up time = 20 x 30 x 10 = 6000 seconds
Config.PlantsGrown1 = 20
Config.PlantsGrown2 = 10
Config.PlantsGrown3 = 5
Config.PlantsWither1 = 20
Config.PlantsWither2 = 10
Config.PlantsWither3 = 5