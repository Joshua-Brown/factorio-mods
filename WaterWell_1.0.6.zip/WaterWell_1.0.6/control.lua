require "defines"
require "utils"

--------------------------------------------------------------------------------------
function on_init()
	debug_level = -1
end

script.on_init( on_init )
script.on_load( on_init )

--------------------------------------------------------------------------------------
script.on_configuration_changed(
	function(data)
		if data.mod_changes ~= nil and data.mod_changes["WaterWell"] ~= nil then
			debug( "update mod: water well" )
			
			for _,force in pairs(game.forces) do
				force.reset_recipes()
				force.reset_technologies()
				
				if force.technologies["steel-processing"].researched then
					force.recipes["water-well-pump"].enabled = true
				end
			end
		end
	end
)

--------------------------------------------------------------------------------------
script.on_event(defines.events.on_tick, 
	function(event)
		if is_first_load == nil then 
			is_first_load = true

			if debug_level >= 0 then
				for _,force in pairs(game.forces) do
					force.reset_recipes()
					force.reset_technologies()
				end
			end
			
			script.on_event(defines.events.on_tick, nil )
		end
	end
)