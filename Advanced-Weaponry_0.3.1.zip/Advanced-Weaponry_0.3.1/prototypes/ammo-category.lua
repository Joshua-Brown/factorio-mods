data:extend({

 {
 type = "ammo-category",
 name = "sniper-bullet"
 },
 
 {
 type = "ammo-category",
 name = "energy-pack"
 },
 
 {
 type = "ammo-category",
 name = "launched-grenade"
 },

})