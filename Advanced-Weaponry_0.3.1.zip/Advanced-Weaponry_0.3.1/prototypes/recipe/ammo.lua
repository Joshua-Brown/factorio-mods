data:extend({

  --Sniper Rifle Ammo
  {
    type = "recipe",
    name = "sniper-rifle-magazine",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 20},
	  {"copper-plate", 20},
      {"iron-plate", 10}
    },
    result = "sniper-rifle-magazine"
  },

  --Laser Ammo
    {
    type = "recipe",
    name = "charge-pack",
    enabled = false,
    energy_required = 5,
    ingredients =
    {
      {"battery", 1},
	  {"copper-plate", 5},
      {"iron-plate", 5}
    },
    result = "charge-pack"
  },

--Launched Grenades
  {
    type = "recipe",
    name = "basic-launched-grenade",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"iron-plate", 5},
      {"coal", 10},
    },
    result = "basic-launched-grenade"
  },

    {
    type = "recipe",
    name = "he-launched-grenade",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"iron-plate", 10},
      {"coal", 20},
    },
    result = "he-launched-grenade"
  },

  {
    type = "recipe",
    name = "poison-launched-grenade",
    enabled = false,
    energy_required = 8,
    ingredients =
    {
      {"steel-plate", 3},
      {"electronic-circuit", 3},
      {"coal", 10},
    },
    result = "poison-launched-grenade"
  },

})