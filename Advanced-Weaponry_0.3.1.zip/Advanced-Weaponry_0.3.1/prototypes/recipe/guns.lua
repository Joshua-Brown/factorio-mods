data:extend({

  --Assault Rifle
  {
    type = "recipe",
    name = "assault-rifle",
    enabled = false,
    energy_required = 3,
    ingredients =
    {
      {"iron-gear-wheel", 15},
      {"steel-plate", 20},
      {"iron-plate", 10}
    },
    result = "assault-rifle"
  },
  
  --Sniper Rifle
  {
    type = "recipe",
    name = "sniper-rifle",
    enabled = false,
    energy_required = 20,
    ingredients =
    {
      {"iron-gear-wheel", 50},
      {"steel-plate", 200},
      {"iron-plate", 100}
    },
    result = "sniper-rifle"
  },

  --Laser Rifle
    {
    type = "recipe",
    name = "laser-rifle",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 50},
	    {"copper-plate", 20},
      {"iron-plate", 10},
	    {"battery", 5}
    },
    result = "laser-rifle"
  },

  --m79
    {
    type = "recipe",
    name = "m79-grenade-launcher",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 30},
      {"iron-gear-wheel", 20},
      {"iron-plate", 10},
    },
    result = "m79-grenade-launcher"
  },

  --mgl
    {
    type = "recipe",
    name = "mgl-grenade-launcher",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 50},
      {"iron-gear-wheel", 20},
      {"iron-plate", 10},
    },
    result = "mgl-grenade-launcher"
  },

  --[[Laser Shotgun
    {
    type = "recipe",
    name = "laser-shotgun",
    enabled = false,
    energy_required = 10,
    ingredients =
    {
      {"steel-plate", 50},
	  {"copper-plate", 20},
      {"iron-plate", 10},
	  {"battery", 5}
    },
    result = "laser-shotgun"
  },  ]]

})