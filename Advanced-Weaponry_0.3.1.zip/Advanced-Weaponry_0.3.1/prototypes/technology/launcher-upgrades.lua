data:extend({


--Launcher Damage
{
type = "technology",
name = "launcher-weapon-damage-1",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-4"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "launched-grenade",
		modifier = "0.1"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 60
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-damage-2",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-damage-1"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "launched-grenade",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 90
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-damage-3",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-damage-2"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "launched-grenade",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 120
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-damage-4",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-damage-3"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "launched-grenade",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 150
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-damage-5",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-damage-4"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "launched-grenade",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 180
	},
order = ""
},

--launcher Speed
{
type = "technology",
name = "launcher-weapon-speed-1",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-4"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "launched-grenade",
		modifier = "0.1"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 60
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-speed-2",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-speed-1"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "launched-grenade",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 90
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-speed-3",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-speed-2"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "launched-grenade",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 120
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-speed-4",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-speed-3"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "launched-grenade",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 150
	},
order = ""
},

{
type = "technology",
name = "launcher-weapon-speed-5",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"launcher-weapon-speed-4"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "launched-grenade",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 180
	},
order = ""
},

})