data:extend({


--Laser Damage
{
type = "technology",
name = "laser-damage-1",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-3"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "energy-pack",
		modifier = "0.1"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 60
	},
order = ""
},

{
type = "technology",
name = "laser-damage-2",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-damage-1"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "energy-pack",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 90
	},
order = ""
},

{
type = "technology",
name = "laser-damage-3",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-damage-2"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "energy-pack",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 120
	},
order = ""
},

{
type = "technology",
name = "laser-damage-4",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-damage-3"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "energy-pack",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 150
	},
order = ""
},

{
type = "technology",
name = "laser-damage-5",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-damage-4"},
effects =
	{
		{
		type = "ammo-damage",
		ammo_category = "energy-pack",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 180
	},
order = ""
},

--Laser Speed
{
type = "technology",
name = "laser-speed-1",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-3"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "energy-pack",
		modifier = "0.1"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 60
	},
order = ""
},

{
type = "technology",
name = "laser-speed-2",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-speed-1"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "energy-pack",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 90
	},
order = ""
},

{
type = "technology",
name = "laser-speed-3",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-speed-2"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "energy-pack",
		modifier = "0.2"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 120
	},
order = ""
},

{
type = "technology",
name = "laser-speed-4",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-speed-3"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "energy-pack",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 150
	},
order = ""
},

{
type = "technology",
name = "laser-speed-5",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"laser-speed-4"},
effects =
	{
		{
		type = "gun-speed",
		ammo_category = "energy-pack",
		modifier = "0.3"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 180
	},
order = ""
},

})