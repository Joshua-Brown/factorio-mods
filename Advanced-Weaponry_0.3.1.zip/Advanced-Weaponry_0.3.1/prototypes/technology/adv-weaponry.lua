data:extend({

{
type = "technology",
name = "adv-weapon-1",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"military-3"},
effects =
	{
		{
		type = "unlock-recipe",
		recipe = "assault-rifle"
		}
	},
unit =
	{
	count = 50,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1}
		},
	time = 30
	},
order = "e-a-e"
},

{
type = "technology",
name = "adv-weapon-2",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-1"},
effects =
	{
		{
		type = "unlock-recipe",
		recipe = "sniper-rifle"
		},
		{
		type = "unlock-recipe",
		recipe = "sniper-rifle-magazine"
		}
	},
unit =
	{
	count = 100,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 60
	},
order = "e-a-f"
},

{
type = "technology",
name = "adv-weapon-3",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-2","laser-turrets"},
effects =
	{
		{
		type = "unlock-recipe",
		recipe = "laser-rifle"
		},
		{
		type = "unlock-recipe",
		recipe = "charge-pack"
		}
	},
unit =
	{
	count = 150,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 90
	},
order = "e-a-g"
},


{
type = "technology",
name = "adv-weapon-4",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-3","explosives"},
effects =
	{
		{
		type = "unlock-recipe",
		recipe = "m79-grenade-launcher"
		},
		{
		type = "unlock-recipe",
		recipe = "basic-launched-grenade"
		},
		{
		type = "unlock-recipe",
		recipe = "poison-launched-grenade"
		}
	},
unit =
	{
	count = 200,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 120
	},
order = "e-a-h"
},

{
type = "technology",
name = "adv-weapon-5",
icon = "__base__/graphics/technology/military.png",
prerequisites = {"adv-weapon-4"},
effects =
	{
		{
		type = "unlock-recipe",
		recipe = "mgl-grenade-launcher"
		},
		{
		type = "unlock-recipe",
		recipe = "he-launched-grenade"
		},
	},
unit =
	{
	count = 250,
	ingredients =
		{
		{"science-pack-1", 1},
		{"science-pack-2", 1},
		{"science-pack-3", 1},
		{"alien-science-pack", 1}
		},
	time = 150
	},
order = "e-a-i"
}

})