data:extend({

 --Assault Rifle
 {
    type = "gun",
    name = "assault-rifle",
    icon = "__base__/graphics/icons/submachine-gun.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "gun",
    order = "a[basic-clips]-b[submachine-gun]-c[assault-rifle]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "bullet",
      cooldown = 5,
      movement_slow_down_factor = 0.5,
	  damage_modifier = 1.5,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 0.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 1.125,
      range = 25,
      sound = make_light_gunshot_sounds(),
    },
    stack_size = 1
  },

 --Sniper Rifle
 {
    type = "gun",
    name = "sniper-rifle",
    icon = "__Advanced-Weaponry__/graphics/sniper-rifle.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "gun",
    order = "a[basic-clips]-b[submachine-gun]-c[assault-rifle]-d[sniper-rifle]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "sniper-bullet",
      cooldown = 80,
      movement_slow_down_factor = 0.9,
	  damage_modifier = 1.5,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 0.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 1.125,
      range = 50,
      sound =
      {
        {
          filename = "__base__/sound/fight/tank-cannon.ogg",
          volume = 0.5
        }
      },
    },
    stack_size = 1
  },
  
 --Laser Rifle
 {
    type = "gun",
    name = "laser-rifle",
    icon = "__Advanced-Weaponry__/graphics/laser-rifle.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "gun",
    order = "d[laser-rifle]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "energy-pack",
      cooldown = 15,
      movement_slow_down_factor = 0.5,
	  damage_modifier = 1,
      shell_particle =
      {
        name = "shell-particle",
        direction_deviation = 0.1,
        speed = 0.1,
        speed_deviation = 0.03,
        center = {0, 0.1},
        creation_distance = -0.5,
        starting_frame_speed = 0.4,
        starting_frame_speed_deviation = 0.1
      },
      projectile_creation_distance = 1.0,
      range = 25,
      sound = make_laser_sounds(),
    },
    stack_size = 1
  },

--Grenade Launcher
  { 
  type = "gun",
  name = "m79-grenade-launcher",
  icon = "__Advanced-Weaponry__/graphics/m79.png",
  flags = {"goes-to-main-inventory"},
  subgroup = "gun",
  order = "e[m79-grenade-launcher]",
  attack_parameters =
    {
    type = "projectile",
    ammo_category = "launched-grenade",
    cooldown = 60,
    movement_slow_down_factor = 0.7,
    damage_modifier = 2,
    projectile_creation_distance = 1.0,
    range = 40,
    --sound = 
    },
  stack_size = 1

  }, 

  { 
  type = "gun",
  name = "mgl-grenade-launcher",
  icon = "__Advanced-Weaponry__/graphics/mgl.png",
  flags = {"goes-to-main-inventory"},
  subgroup = "gun",
  order = "f[mgl-grenade-launcher]",
  attack_parameters =
    {
    type = "projectile",
    ammo_category = "launched-grenade",
    cooldown = 30,
    movement_slow_down_factor = 0.6,
    damage_modifier = 1.5,
    projectile_creation_distance = 1.0,
    range = 35,
    --sound = 
    },
  stack_size = 1

  }, 

  --[[Laser Shotgun
  {
    type = "gun",
    name = "laser-shotgun",
    icon = "__base__/graphics/icons/combat-shotgun.png",
    flags = {"goes-to-main-inventory"},
    subgroup = "gun",
    order = "d[laser-rifle]-e[laser-shotgun]",
    attack_parameters =
    {
      type = "projectile",
      ammo_category = "energy-pack",
      explosion = "explosion-gunshot",
      cooldown = 25,
      movement_slow_down_factor = 0.4,
      damage_modifier = 1.5,
      projectile_creation_distance = 0.6,
      range = 20,
      sound =
      {
        {
          filename = "__base__/sound/pump-shotgun.ogg",
          volume = 0.5
        }
      }
    },
    stack_size = 5
  }, 
  ]]

})