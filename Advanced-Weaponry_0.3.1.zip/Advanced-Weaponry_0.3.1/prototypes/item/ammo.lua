data:extend({

  --Sniper Rifle Ammo
  {
    type = "ammo",
    name = "sniper-rifle-magazine",
    icon = "__Advanced-Weaponry__/graphics/sniper-rifle-magazine.png",
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "sniper-bullet",
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "instant",
          source_effects =
          {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
          },
          target_effects =
          {
            {
              type = "create-entity",
              entity_name = "explosion-hit"
            },
            {
              type = "damage",
              damage = { amount = 200 , type = "physical"}
            }
          }
        }
      }
    },
    magazine_size = 3,
    subgroup = "ammo",
    order = "a[basic-clips]-b[piercing-bullet-magazine]-c[sniper-rifle-magazine]",
    stack_size = 10
  },

  
  --Energy Weapon Ammo
    {
    type = "ammo",
    name = "charge-pack",
    icon = "__Advanced-Weaponry__/graphics/charge-pack.png",
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      type = "projectile",
	  category = "energy-pack",
      action =
      {
        type = "direct",
		action_delivery =
			{
			type="projectile",
			projectile = "laser",
			starting_speed = 1,
			target_effects =
				{
				type = "damage",
				damage = { amount = 20, type="laser"}
				}
			}
      }
    },
    magazine_size = 10,
    subgroup = "ammo",
    order = "d[energy-pack]",
    stack_size = 100
  },
  

--Launched Grenades:
  {
    type = "ammo",
    name = "basic-launched-grenade",
    icon = "__Advanced-Weaponry__/graphics/basic-launched-grenade.png",
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "launched-grenade",
      target_type = "position",
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "projectile",
          projectile = "basic-launched-grenade",
          starting_speed = 0.5,
          source_effects =
          {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
          },
        }
      }
    },
    magazine_size = 1,
    subgroup = "ammo",
    order = "e[basic-launched-grenade]",
    stack_size = 50
  },

--Launched Grenades (High Explosive):
  {
    type = "ammo",
    name = "he-launched-grenade",
    icon = "__Advanced-Weaponry__/graphics/he-launched-grenade.png",
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "launched-grenade",
      target_type = "position",
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "projectile",
          projectile = "he-launched-grenade",
          starting_speed = 0.5,
          source_effects =
          {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
          },
        }
      }
    },
    magazine_size = 1,
    subgroup = "ammo",
    order = "f[he-launched-grenade]",
    stack_size = 50
  },
  
--Launched Grenades (Poison Grenade):
  {
    type = "ammo",
    name = "poison-launched-grenade",
    icon = "__Advanced-Weaponry__/graphics/poison-launched-grenade.png",
    flags = {"goes-to-main-inventory"},
    ammo_type =
    {
      category = "launched-grenade",
      target_type = "position",
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "projectile",
          projectile = "poison-launched-grenade",
          starting_speed = 0.5,
          source_effects =
          {
              type = "create-explosion",
              entity_name = "explosion-gunshot"
          },
        }
      }
    },
    magazine_size = 1,
    subgroup = "ammo",
    order = "g[poison-launched-grenade]",
    stack_size = 50
  },


})