table.insert(
  data.raw["technology"]["fluid-handling"].effects,
  {type = "unlock-recipe",recipe = "check-valve"})
table.insert(
  data.raw["technology"]["fluid-handling"].effects,
  {type = "unlock-recipe",recipe = "overflow-valve"})
table.insert(
  data.raw["technology"]["fluid-handling"].effects,
  {type = "unlock-recipe",recipe = "express-pump"})